"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerSigmaCoverageRoute = registerSigmaCoverageRoute;
const config_schema_1 = require("@kbn/config-schema");
const SIGMA_API_KEY = process.env.SIGMA_API_KEY || '';
function registerSigmaCoverageRoute(router, config) {
    const SIGMA_API_URL = config.sigmaApiUrl;
    router.post({
        path: '/api/babel/coverage/navigator-export',
        options: { access: 'public' },
        security: { authz: { enabled: false, reason: 'Navigator export computed from rule tags only, no privileged data' } },
        validate: {
            body: config_schema_1.schema.object({
                ruleYamls: config_schema_1.schema.arrayOf(config_schema_1.schema.string()),
            }),
        },
    }, async (_context, request, response) => {
        var _a;
        const { ruleYamls } = request.body;
        const authHeader = SIGMA_API_KEY ? `Bearer ${SIGMA_API_KEY}` : '';
        try {
            const fetchRes = await fetch(`${SIGMA_API_URL}/coverage/navigator-export`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json',
                    ...(authHeader ? { authorization: authHeader } : {}),
                },
                body: JSON.stringify({ rule_yamls: ruleYamls }),
            });
            const payload = await fetchRes.json().catch(() => null);
            if (!fetchRes.ok) {
                return response.customError({
                    statusCode: fetchRes.status,
                    body: { message: (_a = payload === null || payload === void 0 ? void 0 : payload.detail) !== null && _a !== void 0 ? _a : 'Navigator export failed' },
                });
            }
            return response.ok({ body: payload });
        }
        catch (err) {
            const _msg = err instanceof Error ? err.message : 'Navigator export failed';
            if (err instanceof TypeError)
                return response.customError({ statusCode: 503, body: { message: `Sigma API unreachable: ${_msg}` } });
            return response.internalError({ body: { message: _msg } });
        }
    });
    router.post({
        path: '/api/babel/coverage',
        options: { access: 'public' },
        security: { authz: { enabled: false, reason: 'Coverage is computed from rule tags, no privileged data access' } },
        validate: {
            body: config_schema_1.schema.object({
                ruleYamls: config_schema_1.schema.arrayOf(config_schema_1.schema.string()),
            }),
        },
    }, async (_context, request, response) => {
        var _a;
        const { ruleYamls } = request.body;
        const authHeader = SIGMA_API_KEY ? `Bearer ${SIGMA_API_KEY}` : '';
        try {
            const fetchRes = await fetch(`${SIGMA_API_URL}/coverage`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json',
                    ...(authHeader ? { authorization: authHeader } : {}),
                },
                body: JSON.stringify({ rule_yamls: ruleYamls }),
            });
            const payload = await fetchRes.json().catch(() => null);
            if (!fetchRes.ok) {
                return response.customError({
                    statusCode: fetchRes.status,
                    body: { message: (_a = payload === null || payload === void 0 ? void 0 : payload.detail) !== null && _a !== void 0 ? _a : 'Coverage computation failed' },
                });
            }
            return response.ok({ body: payload });
        }
        catch (err) {
            const _msg = err instanceof Error ? err.message : 'Coverage computation failed';
            if (err instanceof TypeError)
                return response.customError({ statusCode: 503, body: { message: `Sigma API unreachable: ${_msg}` } });
            return response.internalError({ body: { message: _msg } });
        }
    });
}
//# sourceMappingURL=sigma_coverage.js.map